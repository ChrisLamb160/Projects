//making the array
var x = []; 

function setup() {

	createCanvas(400, 400);

//pre set array
var r = [99, 66, 44, 22];
 
 //output to console for pre set array
  print('in the array there is ' + r.length);
  print('in the array, the first array is ' + r[0]);
  print('in the array, the second array is ' + r[1]);
  print('in the array, the third array is ' + r[2]);
  print('in the array, the forth array is ' + r[3]);

  
  
//creating the loop array
	noStroke();
	fill(255);
	for (var i = 0; i < 5000; i++) {

//assigning values
	x[i] = random(-2500, 100); 
}
}

function draw() {

//making the pumpkin
background(100);
//stem
  stroke(0,255,0);
  strokeWeight(25);
  line(200, 125, 250, 75);
 //body
  stroke(0);
  strokeWeight(0)
  fill(255, 69, 0);
  ellipse(200, 200, 300, 150);
  //face
  fill(0);
  circle(125, 175, 25);
  circle(275, 175, 25);
  triangle(180, 215, 220, 215, 200, 175);
  arc(200, 225, 80, 80, 0, 3.1);

  
//determine when the for loop ends via loop
	for (var i = 0; i < x.length; i++) {

//ceating x axis speed
	x[i] += 3;

//using the i value to set the object on the y axis
	var y = i * 0.5;
      
//drawing the shape based on array
a = random(0,0); 
b = random(255, 69); 

  ellipse(x[i], y, 10, 20);
  fill(a,b);
 }
}