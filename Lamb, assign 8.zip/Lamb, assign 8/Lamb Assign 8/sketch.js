  
  let img;
  let img2;
  let gif;

function preload(){
  img = loadImage('balloon.jpg');
  img2 = loadImage('sun.jpg');
  gif = loadImage('pikachu.gif');
}

function setup() {
  createCanvas(400, 400);
  
  //remove the "//" and replace on font for Helvetica to use google font
  textFont("Helvetica");
  //textFont("Pacifico");
  
  fill(0);
  stroke(255);
}

function draw() {
  background(102);
  
  image(img2, 50, 50, 50, 50)
  image(img, 100, 100, mouseX * 2, mouseY * 2);
  image(gif, 5, mouseY * -0.5);
  
  textSize(32);
  text("this is a test for text", 25, 25) 
  textSize(15); 
  text(16);
  text("this is a test for height and width", 10, 300, 70, 80);}