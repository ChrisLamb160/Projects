let angle = 0;


let leftWall2 = 10;
let rightWall2 = 60;
let topWall2 = 10;
let bottomWall2 = 100;

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}


function draw() {
  background(220);
  //mau5(110, 110);
    man(200, 200);
    flag(20, 20);
  
  scale(0.5);
  
for (var x = 35; x < width +200; x += 80) {
  push();
  translate(10,50);
  rotate(angle);
  mau5(x, 200);
  pop();
  }
 angle = angle + 1; 
  
   if ((mouseX > leftWall2) && (mouseX < rightWall2) && (mouseY > topWall2) && (mouseY < bottomWall2)) {
  print('You have reached the Flag!');
}
}



function flag(x, y) {
push();//create a new drawing state
translate(x, y);
stroke(0);
   
    line(10, 80, 10, 20);
    line(10, 20, 40, 40);
    line(10, 40, 40, 40);
    
pop();
}
function man(x, y) {
push();
translate(mouseX, mouseY);
stroke(0);
    
  
    line(80, 60, 50, 100);
    line(80, 60, 110, 100);
  
    line(100, 150, 87, 100);
    line(60, 150, 72, 100);
  
    ellipse(80, 80, 25, 50);//body 
    ellipse(80, 40, 50, 50);//head
 
  
    fill(122);
    ellipse(80, 50, 4, 4);//nose

fill(0);
ellipse(94, 40, 8, 8);//Left eye
ellipse(64, 40, 8, 8);//Right eye

pop();//return the drawing state to it's original state, before the push() function
  }   

function mau5(x, y) {
push();//create a new drawing state
translate(x,y);
stroke(0);
    ellipse(60, 20, 30, 30);//left ear
    ellipse(100, 20, 30, 30);//right ear
    ellipse(80, 40, 50, 50);//head
 
    fill(122);
    ellipse(80, 50, 4, 4);//nose

fill(0);
ellipse(94, 40, 8, 8);//Left eye
ellipse(64, 40, 8, 8);//Right eye
pop();//return the drawing state to it's original state, before the push() function
}